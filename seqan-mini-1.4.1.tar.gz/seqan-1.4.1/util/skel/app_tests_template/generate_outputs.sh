#!/bin/sh
#
# Output generation script for %(APP_NAME)s

%(APP_NAME_U)s=../../../../build/Debug/%(LOCATION)s/%(APP_NAME)s

# ============================================================
# First Section
# ============================================================

${%(APP_NAME_U)s} PUT PARAMS HERE > EXAMPLE.stdout
