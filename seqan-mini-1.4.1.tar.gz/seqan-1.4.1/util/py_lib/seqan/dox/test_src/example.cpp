/*!
 * @class A
 * @brief This is a class.
 * @class B
 * @brief This is another class.
 */

/*!
 * @concept Konzept
 * @brief This is a KONZERT!
 * @class Foo
 * @implements Konzept
 */
