#include <iostream>

int main(int arg, char const ** argv)
{
    //![Print to stdout]
    std::cout << "This is an example.\n";
    //![Print to stdout]
    return 0;
}
