"some comment /* in a string */"

/**
 * Test comment.
   */

/*!
 * Test comment...
*/
