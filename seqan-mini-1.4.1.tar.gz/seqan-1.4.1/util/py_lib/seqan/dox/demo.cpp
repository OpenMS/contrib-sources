// demo.cpp

int main(int argc, char const ** argv)
{
//![block marker]
    int x = 10;
//![block marker]
    return 0;
}
