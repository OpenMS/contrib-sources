#!/usr/bin/env python

import sys

import app

main = app.main

if __name__ == '__main__':
    sys.exit(main())
